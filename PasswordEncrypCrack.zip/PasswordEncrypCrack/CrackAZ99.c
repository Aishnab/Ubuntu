#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <stdbool.h>
#include <crypt.h>
#include <string.h>


#define NUM_THREADS 12
#define START_CHAR 'A'
#define END_CHAR 'Z'
#define MAX_NUM 99

int count = 0;

// Copy and Paste your ecrypted password here using EncryptShA512 program
char *salt_and_encrypted = "$6$AS$Po8x9kcr3Tz/qwEFEg6GbQMa6jW2b.uWo3BB0CY4Wp5sr5MXGAS9FqFh4JeCLcUGyOuxo5O/Ny5Yr2J4XlI1X."; 

// Structure to hold thread arguments
typedef struct {
    int thread_id;
} ThreadArgs;

// Mutex for synchronized output and shared variable access
pthread_mutex_t mutex;

// Shared variable to signal threads to stop
bool stop_threads = false;

void substr(char *dest, char *src, int start, int length){
  memcpy(dest, src + start, length);
  *(dest + length) = '\0';
}


// Function to be executed by each thread
void *decrypt(void *args) {
    ThreadArgs *thread_args = (ThreadArgs *)args;
    int thread_id = thread_args->thread_id;
    char *enc;
    char plain[7];
    char salt[7];
    int i;


    substr(salt, salt_and_encrypted, 0, 6);

    for (char first = START_CHAR; first <= END_CHAR; first++) {
        for (char second = START_CHAR; second <= END_CHAR; second++) {
            for (int num = 0; num <= MAX_NUM; num++) {
                // Check if threads should stop
                pthread_mutex_lock(&mutex);
                if (stop_threads) {
                    pthread_mutex_unlock(&mutex);
                    return NULL;
                }
                pthread_mutex_unlock(&mutex);

                // Assign work to this thread based on thread_id
                if ((first * 26 * 100 + second * 100 + num) % NUM_THREADS == thread_id) {
                    pthread_mutex_lock(&mutex);
                    sprintf(plain, "%c%c%02d", first, second, num);
                    enc = (char *) crypt(plain, salt);
                    count++;

                    //
                    // Check for the stopping condition
                    if (strcmp(salt_and_encrypted, enc) == 0) {
                        printf("password found @%-8d %s %s\n", count, plain, enc);
                        printf("%d solutions explored\n", count);
                        stop_threads = true;
                        pthread_mutex_unlock(&mutex);
                        return NULL;
                    }
                    pthread_mutex_unlock(&mutex);
                }
            }
        }
    }
    return NULL;
}

int main() {
    pthread_t threads[NUM_THREADS];
    ThreadArgs thread_args[NUM_THREADS];

    // Initialize the mutex
    pthread_mutex_init(&mutex, NULL);

    // Create threads
    for (int i = 0; i < NUM_THREADS; i++) {
        thread_args[i].thread_id = i;
        if (pthread_create(&threads[i], NULL, decrypt, &thread_args[i]) != 0) {
            perror("Failed to create thread");
            return 1;
        }
    }

    // Wait for all threads to finish
    for (int i = 0; i < NUM_THREADS; i++) {
        pthread_join(threads[i], NULL);
    }

    // Destroy the mutex
    pthread_mutex_destroy(&mutex);

    return 0;
}