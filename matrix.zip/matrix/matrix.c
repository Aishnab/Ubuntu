#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

// Structure to hold matrix data and the row index to compute
typedef struct {
    int *A;
    int *B;
    int *C;
    int A_rows;
    int A_cols;
    int B_rows;
    int B_cols;
    int row;
} MatrixData;

// Function to read a matrix from a file
void readMatrix(FILE *file, int *rows, int *cols, int **matrix) {
    fscanf(file, "%d %d", rows, cols);
    *matrix = (int *)malloc((*rows) * (*cols) * sizeof(int));  // 1D Array
    for (int i = 0; i < *rows; i++) {
        for (int j = 0; j < *cols; j++) {
            fscanf(file, "%d", &(*matrix)[i * (*cols) + j]);  // 2D access with 1D array
        }
    }
}

// Function to multiply a row of Matrix A by Matrix B and store the result in Matrix C
void *multiplyRow(void *arg) {
    MatrixData *data = (MatrixData *)arg;
    for (int j = 0; j < data->B_cols; j++) {
        data->C[data->row * data->B_cols + j] = 0;  // Initialize element in result matrix C
        for (int k = 0; k < data->A_cols; k++) {
            // Perform the multiplication for the row
            data->C[data->row * data->B_cols + j] +=
                data->A[data->row * data->A_cols + k] * data->B[k * data->B_cols + j];
        }
    }
    pthread_exit(NULL);
}

int main(int argc, char *argv[]) {
    if (argc < 3) {
        printf("Usage: %s <input file> <number of threads>\n", argv[0]);
        return 1;
    }

    FILE *file = fopen(argv[1], "r");
    if (!file) {
        printf("Error opening file!\n");
        return 1;
    }

    int rowsA, colsA, rowsB, colsB;
    int *matrixA, *matrixB;

    // Read Matrix A
    readMatrix(file, &rowsA, &colsA, &matrixA);
    // Read Matrix B
    readMatrix(file, &rowsB, &colsB, &matrixB);
    fclose(file);
        printf("Matrix A: %d x %d\n", rowsA, colsA);
        printf("Matrix B: %d x %d\n", rowsB, colsB);

    // Check matrix multiplication compatibility
    if (colsA != rowsB) {
        printf("Matrices cannot be multiplied.\n");
        return 1;
    }

    // Allocate memory for result matrix C (1D array)
    int *matrixC = (int *)malloc(rowsA * colsB * sizeof(int));

    // Create threads for matrix multiplication
    int numThreads = atoi(argv[2]);
    numThreads = (numThreads > rowsA) ? rowsA : numThreads;  // Limit threads to rowsA

    pthread_t threads[numThreads];
    MatrixData data[numThreads];

    // Create threads to compute each row of Matrix C
    for (int i = 0; i < numThreads; i++) {
        data[i].A = matrixA;
        data[i].B = matrixB;
        data[i].C = matrixC;
        data[i].A_rows = rowsA;
        data[i].A_cols = colsA;
        data[i].B_rows = rowsB;
        data[i].B_cols = colsB;
        data[i].row = i;
        pthread_create(&threads[i], NULL, multiplyRow, (void *)&data[i]);
    }

    // Wait for all threads to complete
    for (int i = 0; i < numThreads; i++) {
        pthread_join(threads[i], NULL);
    }

    // Write the result matrix to the output file
    FILE *output = fopen("output.txt", "w");
    if (!output) {
        printf("Error opening output file!\n");
        return 1;
    }

    fprintf(output, "%d %d\n", rowsA, colsB);
    for (int i = 0; i < rowsA; i++) {
        for (int j = 0; j < colsB; j++) {
            fprintf(output, "%d ", matrixC[i * colsB + j]);  // Access in 1D array format
        }
        fprintf(output, "\n");
    }

    fclose(output);

    // Free memory
    free(matrixA);
    free(matrixB);
    free(matrixC);

    return 0;
}
